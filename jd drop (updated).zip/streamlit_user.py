# streamlit_user.py — User-facing JD→Resume retrieval (robust hybrid)
import io
import os
import re
import json
from pathlib import Path
from typing import List, Dict, Tuple

import streamlit as st
import pandas as pd
import requests
import chromadb
from rank_bm25 import BM25Okapi
from pypdf import PdfReader
from docx import Document as Docx

from config import (
    CHROMA_DIR, CHROMA_COLLECTION,
    RESUMES_STORE_DIR,
    BM25_CORPUS_PATH, BM25_DOCIDS_PATH, BM25_META_PATH,
    EMBED_MODEL, OLLAMA_HOST,
    MAX_QUERY_CHARS, OLLAMA_TIMEOUT,
    QUERY_CHUNK_SIZE, QUERY_CHUNK_OVERLAP, QUERY_MAX_CHUNKS,
    K_VEC, K_BM25, K_CHUNKS, HYBRID_ALPHA,
    USE_RRF, RRF_K, USE_MMR, MMR_LAMBDA,
    TOP_K_FINAL,
)

# -------------------------
# Utilities
# -------------------------

@st.cache_resource(show_spinner=False)
def get_http_session():
    s = requests.Session()
    s.headers.update({"Content-Type": "application/json"})
    return s


def get_ollama_base() -> str:
    base = (OLLAMA_HOST or "").strip().rstrip("/")
    if not base:
        base = "http://localhost:11434"
    return base


def strip_rtf_noise(txt: str) -> str:
    if not isinstance(txt, str):
        return ""
    s = txt
    if s.lstrip().startswith("{\\rtf"):
        s = re.sub(r"[{}]", " ", s)
        s = re.sub(r"\\[a-zA-Z]+\d* ?", " ", s)  # \par, \b0, \fs22, etc.
    return re.sub(r"\s+", " ", s).strip()


ALIASES = {
    ".net": "dotnet", "c#": "csharp", "c++": "cpp",
    "node.js": "nodejs", "react.js": "react", "next.js": "nextjs",
    "javascript": "js", "typescript": "ts",
}


def normalize_for_bm25(text: str) -> str:
    s = (text or "").lower()
    for a,b in ALIASES.items():
        s = s.replace(a, b)
    return s


def chunk_text_query(text: str, size: int = QUERY_CHUNK_SIZE, overlap: int = QUERY_CHUNK_OVERLAP, max_chunks: int = QUERY_MAX_CHUNKS) -> List[str]:
    s = (text or "").strip()
    if len(s) > MAX_QUERY_CHARS:
        s = s[:MAX_QUERY_CHARS]
    if not s:
        return []
    chunks = []
    i = 0
    while i < len(s) and len(chunks) < max_chunks:
        chunks.append(s[i:i+size])
        i = i + size - overlap
        if i <= 0:
            break
    return chunks


@st.cache_resource(show_spinner=False)
def get_chroma():
    client = chromadb.PersistentClient(path=CHROMA_DIR)
    try:
        coll = client.get_collection(CHROMA_COLLECTION)
    except Exception:
        coll = client.create_collection(CHROMA_COLLECTION, metadata={"hnsw:space": "cosine"})
    return client, coll


@st.cache_resource(show_spinner=False)
def load_bm25_index():
    import pickle
    class _NullBM25:
        corpus_size = 0
        def get_scores(self, tokens):
            return []
    if not (os.path.exists(BM25_CORPUS_PATH) and os.path.exists(BM25_DOCIDS_PATH)):
        return _NullBM25(), [], {}, {}
    with open(BM25_CORPUS_PATH, "rb") as f:
        corpus_tokens = pickle.load(f)
    with open(BM25_DOCIDS_PATH, "rb") as f:
        doc_ids = pickle.load(f)
    bm25 = _NullBM25() if (not corpus_tokens or all((not d) for d in corpus_tokens)) else BM25Okapi(corpus_tokens)
    id2pos = {d: i for i, d in enumerate(doc_ids)}
    meta_by_id = {}
    if os.path.exists(BM25_META_PATH) and os.path.getsize(BM25_META_PATH) > 0:
        with open(BM25_META_PATH, "rb") as f:
            meta_by_id = pickle.load(f)
    return bm25, doc_ids, id2pos, meta_by_id


# -------------------------
# Embeddings (Ollama HTTP first, then langchain_ollama fallback)
# -------------------------

@st.cache_data(show_spinner=False)
def embed_query(text: str) -> List[float]:
    session = get_http_session()
    base = get_ollama_base()
    url = base + "/api/embeddings"

    txt = (text or "").strip()
    if not txt:
        raise ValueError("Empty query text")
    if len(txt) > MAX_QUERY_CHARS:
        txt = txt[:MAX_QUERY_CHARS]

    try:
        r = session.post(url, json={"model": EMBED_MODEL, "input": txt}, timeout=OLLAMA_TIMEOUT)
        if r.status_code == 400:
            r = session.post(url, json={"model": EMBED_MODEL, "prompt": txt}, timeout=OLLAMA_TIMEOUT)
        r.raise_for_status()
        data = r.json()
        vec = data.get("embedding") or data.get("data", [{}])[0].get("embedding")
        if not vec:
            raise RuntimeError("No embedding returned from Ollama")
        return vec
    except Exception:
        # Fallback: langchain_ollama (avoid deprecated langchain.embeddings)
        try:
            from langchain_ollama import OllamaEmbeddings
        except Exception:
            from langchain_community.embeddings import OllamaEmbeddings  # last resort
        emb = OllamaEmbeddings(model=EMBED_MODEL, base_url=base)
        return emb.embed_query(txt)


@st.cache_data(show_spinner=False)
def embed_query_pooled(text: str) -> List[float]:
    chunks = chunk_text_query(text)
    if not chunks:
        return embed_query(text)  # tiny queries
    vecs = [embed_query(c) for c in chunks]
    # length-weighted mean
    dims = len(vecs[0])
    acc = [0.0] * dims
    total = 0
    for c, v in zip(chunks, vecs):
        w = max(1, len(c))
        for i in range(dims):
            acc[i] += v[i] * w
        total += w
    return [x / max(1, total) for x in acc]


# -------------------------
# Retrieval: union(vector@K, bm25@K) → RRF → score fusion → MMR diversity
# -------------------------

def _norm(arr: List[float]) -> List[float]:
    if not arr:
        return []
    mn, mx = min(arr), max(arr)
    if mx - mn < 1e-9:
        return [0.0 for _ in arr]
    return [(x - mn) / (mx - mn) for x in arr]


def _rrf_fuse(rankings: Dict[str, List[str]], k: int = RRF_K) -> Dict[str, float]:
    scores: Dict[str, float] = {}
    for _, ids in rankings.items():
        for r, cid in enumerate(ids, start=1):
            scores[cid] = scores.get(cid, 0.0) + 1.0 / (k + r)
    return scores


def retrieve_candidates_union(jd_text: str, k_vec: int, k_bm25: int):
    # pooled query embedding
    qvec = embed_query_pooled(jd_text)

    client, coll = get_chroma()
    q = coll.query(
        query_embeddings=[qvec],
        n_results=k_vec,
        include=["documents", "metadatas", "distances", "embeddings"],
    )

    ids_v   = q.get("ids", [[]])[0]
    docs_v  = q.get("documents", [[]])[0]
    metas_v = q.get("metadatas", [[]])[0]
    dists_v = q.get("distances", [[]])[0]
    embs_v  = q.get("embeddings", [[]])[0]

    # Avoid ambiguous truth-value on numpy arrays
    has_embs = embs_v is not None and hasattr(embs_v, "__len__") and len(embs_v) >= len(ids_v)

    sem_v = [1.0 - d for d in dists_v]

    C: Dict[str, Dict] = {}
    for i, cid in enumerate(ids_v):
        key = metas_v[i].get("chunk_id", cid)
        C.setdefault(key, {"doc": strip_rtf_noise(docs_v[i]), "sem": 0.0, "kw": 0.0, "meta": metas_v[i], "emb": embs_v[i] if has_embs else None})
        C[key]["sem"] = max(C[key]["sem"], sem_v[i])

    # BM25 side (global top-K)
    bm25, doc_ids, id2pos, meta_by_id = load_bm25_index()
    kw_top: List[str] = []
    kw_scores_map: Dict[str, float] = {}
    if getattr(bm25, "corpus_size", 0) > 0 and id2pos:
        toks = normalize_for_bm25(jd_text)
        toks = toks.split()  # utils.tokenize variant; we used simple split after normalize
        scores = bm25.get_scores(toks)
        # build (chunk_id, score) pairs from id2pos safely
        pairs = [(cid, float(scores[pos])) for cid, pos in id2pos.items() if pos < len(scores)]
        pairs.sort(key=lambda x: x[1], reverse=True)
        for cid, sc in pairs[:k_bm25]:
            kw_top.append(cid)
            kw_scores_map[cid] = sc

        if kw_top:
            try:
                got = coll.get(where={"chunk_id": {"$in": kw_top}}, include=["documents","metadatas","ids"])
                got_ids  = got.get("ids", []) or []
                got_docs = got.get("documents", []) or []
                got_meta = got.get("metadatas", []) or []
                for i in range(len(got_ids)):
                    cid = got_meta[i].get("chunk_id", got_ids[i])
                    C.setdefault(cid, {"doc": strip_rtf_noise(got_docs[i]), "sem": 0.0, "kw": 0.0, "meta": got_meta[i], "emb": None})
            except Exception:
                pass

        for cid, sc in kw_scores_map.items():
            C.setdefault(cid, {"doc": "", "sem": 0.0, "kw": 0.0, "meta": meta_by_id.get(cid,{"chunk_id": cid}), "emb": None})
            C[cid]["kw"] = max(C[cid]["kw"], sc)

    # rankings for optional RRF
    if USE_RRF:
        sem_rank = sorted(C.keys(), key=lambda k: C[k]["sem"], reverse=True)
        kw_rank  = sorted(C.keys(), key=lambda k: C[k]["kw" ], reverse=True)
        rrf = _rrf_fuse({"semantic": sem_rank, "bm25": kw_rank}, k=RRF_K)
    else:
        rrf = {k: 0.0 for k in C.keys()}

    # normalize sem & kw, then fuse + rrf
    keys = list(C.keys())
    sem_n = _norm([C[k]["sem"] for k in keys])
    kw_n  = _norm([C[k]["kw" ] for k in keys])

    fused = {}
    for i, k in enumerate(keys):
        s = float(HYBRID_ALPHA) * sem_n[i] + (1.0 - float(HYBRID_ALPHA)) * kw_n[i]
        fused[k] = 0.5 * s + 0.5 * rrf.get(k, 0.0) if USE_RRF else s

    # order by fused
    ordered = sorted(keys, key=lambda k: fused[k], reverse=True)

    # Optional MMR diversity (approx — uses stored candidate embeddings if available)
    if USE_MMR and ordered:
        try:
            import numpy as np
            def cos(a,b):
                na, nb = np.linalg.norm(a), np.linalg.norm(b)
                return 0.0 if na==0 or nb==0 else float(np.dot(a,b)/(na*nb))
            selected = [ordered[0]]
            remaining = ordered[1:]
            # Build embedding lookup (fallback to query vec similarity if missing)
            def emb(cid):
                e = C[cid].get("emb")
                if e is None:
                    return None
                try:
                    return np.asarray(e, dtype=float)
                except Exception:
                    return None
            while remaining and len(selected) < min(K_CHUNKS, len(ordered)):
                best_idx, best_score = 0, -1e9
                for i, cid in enumerate(remaining):
                    # encourage dissimilarity to already selected
                    redun = max((cos(emb(cid), emb(s)) for s in selected if emb(cid) is not None and emb(s) is not None), default=0.0)
                    score = float(MMR_LAMBDA) * (1.0 - redun) + (1.0 - float(MMR_LAMBDA)) * 0.0
                    if score > best_score:
                        best_score, best_idx = score, i
                selected.append(remaining.pop(best_idx))
            final_ids = selected
        except Exception:
            final_ids = ordered[:K_CHUNKS]
    else:
        final_ids = ordered[:K_CHUNKS]

    # materialize candidates as list of dicts
    out = []
    for cid in final_ids:
        item = C[cid]
        md = dict(item.get("meta") or {})
        md.setdefault("chunk_id", cid)  # ensure chunk_id exists in meta
        out.append({
            "chunk_id": cid,
            "doc": item.get("doc", ""),
            "meta": md,
            "sem": item.get("sem", 0.0),
            "kw": item.get("kw", 0.0),
            "score": fused.get(cid, 0.0),
        })
    return out


def parent_pool(cands: List[Dict]) -> List[Dict]:
    """Aggregate chunk-level candidates into resume-level rows (keep best evidence)."""
    buckets: Dict[str, Dict] = {}
    for c in cands:
        md = c.get("meta") or {}
        # prefer explicit ids, then chunk_id, then filename stem
        parent = (
            md.get("parent_id") or
            md.get("resume_id") or
            md.get("document_id") or
            md.get("chunk_parent") or
            md.get("chunk_id") or
            c.get("chunk_id") or
            (Path(md.get("file_path","" )).stem if md.get("file_path") else "unknown")
        )
        file_path = md.get("file_path")
        preview = c.get("doc", "")[:800]
        row = buckets.get(parent)
        score = float(c.get("score", 0.0))
        if (row is None) or (score > row["score"]):
            buckets[parent] = {
                "parent_id": parent,
                "file_path": file_path,
                "score": score,
                "preview": preview,
            }
    ranked = sorted(buckets.values(), key=lambda r: r["score"], reverse=True)[:TOP_K_FINAL]
    # show percentages relative to best score; top == 100%
    if ranked:
        vmax = max(r["score"] for r in ranked)
        if vmax <= 0:
            for r in ranked:
                r["match_pct"] = 0
        else:
            for r in ranked:
                r["match_pct"] = int(round(100 * (r["score"] / vmax)))
    return ranked


# -------------------------
# UI
# -------------------------

st.set_page_config(page_title="JD→Resume Search", page_icon="🔎", layout="wide")
st.title("JD–Resume Search")
st.caption("Paste a JD or upload a file; we’ll retrieve top-matching resumes from the secured store.")

left, right = st.columns([2,1])
with left:
    jd_text_area = st.text_area("Job description (paste)", height=200, placeholder="Paste the JD here…")
    st.markdown("**OR**")
    jd_file = st.file_uploader("Upload JD file (PDF/DOCX/TXT/RTF)", type=["pdf","docx","txt","rtf"])

with right:
    st.subheader("Search settings")
    st.write(f"Hybrid α (semantic vs keyword): **{HYBRID_ALPHA}**")
    st.write(f"Vector@K: **{K_VEC}**, BM25@K: **{K_BM25}**, Evidence chunks: **{K_CHUNKS}**")
    st.write(f"RRF: **{USE_RRF}** (K={RRF_K}), MMR: **{USE_MMR}** (λ={MMR_LAMBDA})")
    st.write(f"Results: **Top {TOP_K_FINAL} resumes**")

# Parse JD from upload if provided
if jd_file is not None and not jd_text_area.strip():
    # Minimal readers for JD text
    try:
        if jd_file.type == "application/pdf":
            reader = PdfReader(io.BytesIO(jd_file.read()))
            jd_text_area = "\n".join(p.extract_text() or "" for p in reader.pages)
        elif jd_file.type in ("application/vnd.openxmlformats-officedocument.wordprocessingml.document",):
            doc = Docx(io.BytesIO(jd_file.read()))
            jd_text_area = "\n".join(p.text or "" for p in doc.paragraphs)
        else:
            jd_text_area = jd_file.read().decode("utf-8", errors="ignore")
    except Exception as e:
        st.error(f"Failed to read JD file: {e}")

# Run search
if st.button("Search", type="primary"):
    text = (jd_text_area or "").strip()
    if not text:
        st.warning("Please paste a JD or upload a JD file.")
    else:
        try:
            cands = retrieve_candidates_union(text, K_VEC, K_BM25)
            results = parent_pool(cands)

            st.subheader("Top matches")
            if not results:
                st.info("No matches found. Try increasing K or adjusting α.")
            for i, r in enumerate(results, 1):
                with st.expander(f"{i}. Match {r.get('match_pct',0)}% — {r.get('parent_id')} "):
                    st.write(r.get("preview") or "(no preview)")
                    fp = r.get("file_path")
                    if fp and Path(fp).exists():
                        with open(fp, "rb") as fh:
                            data = fh.read()
                        base_name = Path(fp).name
                        st.download_button("Download resume", data, file_name=base_name)
                    else:
                        st.caption("Original file not found on server.")
        except Exception as e:
            st.error(f"Search failed: {e}")

st.divider()
st.caption("User view. Read-only access to the vector DB. Uploads are disabled for users by design.")