# streamlit_admin.py
import io
import os
import time
import math
import pickle
from pathlib import Path
from typing import List, Dict, Tuple

import streamlit as st
import pandas as pd
import chromadb
import requests
from pypdf import PdfReader
from docx import Document as Docx

from config import (
    CHROMA_DIR, CHROMA_COLLECTION, INDEX_DIR,
    BM25_CORPUS_PATH, BM25_META_PATH, EMBED_MODEL,
    RESUMES_STORE_DIR, ALLOWED_EXTS, BM25_DOCIDS_PATH,
    CHUNK_SIZE, CHUNK_OVERLAP
)
from utils_text import clean_text, tokenize, simple_metadata
from langsmith import Client, traceable
import hashlib


st.set_page_config(page_title="JD–Resume Admin", page_icon="🗂️", layout="wide")

# ---------- Helpers ----------

def chunk_text(text: str, size: int, overlap: int) -> List[str]:
    """Simple character-level chunker with overlap. No external deps."""
    text = text or ""
    n = len(text)
    if n == 0:
        return []
    size = max(1, int(size))
    overlap = max(0, int(overlap))
    if overlap >= size:
        overlap = size // 4  # guard
    chunks = []
    start = 0
    while start < n:
        end = min(n, start + size)
        chunks.append(text[start:end])
        if end == n:
            break
        start = max(0, end - overlap)
    return chunks

@st.cache_resource(show_spinner=False)
def get_chroma():
    # Compatible with ChromaDB v0.3–0.5+
    try:
        if hasattr(chromadb, "PersistentClient"):
            client = chromadb.PersistentClient(path=CHROMA_DIR)
        else:
            # older API
            from chromadb.config import Settings
            client = chromadb.Client(Settings(chroma_db_impl="duckdb+parquet", persist_directory=CHROMA_DIR))
    except Exception:
        st.error(
            "Failed to initialize Chroma client. Upgrade chromadb with `pip install -U chromadb==0.5.5` or ensure the older Settings-based API is available.",
            icon="⚠️",
        )
        raise
    coll = client.get_or_create_collection(name=CHROMA_COLLECTION)
    os.makedirs(INDEX_DIR, exist_ok=True)
    os.makedirs(RESUMES_STORE_DIR, exist_ok=True)
    return client, coll

def _chunk_stats(chunks: List[str], text_len: int, size: int, overlap: int) -> Dict:
    """Compute detailed chunk statistics for LangSmith logging."""
    stats = {
        "chunk_count": 0,
        "chunk_length_mean": 0,
        "chunk_length_median": 0,
        "chunk_length_p95": 0,
        "chunk_length_min": 0,
        "chunk_length_max": 0,
        "chunk_size_cfg": size,
        "chunk_overlap_cfg": overlap,
        "chunk_lengths_sample": [],
        "chunk_lengths_sampled_n": 0,
        "empty_chunk_count": 0,
        "last_chunk_len": 0,
        "expected_chunk_count": 0,
        "chunk_count_deviation": 0,
        "percent_within_band": 0.0,
        "tail_shrink_ratio": 0.0,
        "coverage_chars_unique_approx": 0,
        "coverage_ratio": 1.0,
        "text_len": int(text_len or 0),
    }
    if not chunks:
        return stats

    lens = [len(c) for c in chunks]
    n = len(lens)
    stats["chunk_count"] = n
    stats["empty_chunk_count"] = sum(1 for L in lens if L == 0)
    stats["last_chunk_len"] = lens[-1] if n else 0
    stats["chunk_length_min"] = min(lens)
    stats["chunk_length_max"] = max(lens)
    stats["chunk_length_mean"] = sum(lens) / n
    lens_sorted = sorted(lens)
    # median
    if n % 2 == 1:
        stats["chunk_length_median"] = lens_sorted[n // 2]
    else:
        stats["chunk_length_median"] = (lens_sorted[n // 2 - 1] + lens_sorted[n // 2]) / 2
    # p95
    p95_idx = max(0, int(0.95 * (n - 1)))
    stats["chunk_length_p95"] = lens_sorted[p95_idx]
    # sample of lengths to avoid huge payloads
    stats["chunk_lengths_sample"] = lens[:200]
    stats["chunk_lengths_sampled_n"] = min(n, 200)

    # metrics vs config
    size = max(1, int(size))
    overlap = max(0, int(overlap))
    expected = math.ceil(text_len / size) if size > 0 else n
    stats["expected_chunk_count"] = expected
    stats["chunk_count_deviation"] = n - expected

    # within-band %: [0.6 * size, 1.0 * size]
    lo = int(0.6 * size)
    hi = size
    within = sum(1 for L in lens if lo <= L <= hi)
    stats["percent_within_band"] = (within / n) if n else 0.0

    # tail shrink ratio
    stats["tail_shrink_ratio"] = (stats["last_chunk_len"] / size) if size else 0.0

    # coverage (approx): sum(lens) / (text_len + (n - 1) * overlap)
    denom = (text_len + max(0, n - 1) * overlap)
    stats["coverage_chars_unique_approx"] = denom
    stats["coverage_ratio"] = (sum(lens) / denom) if denom > 0 else 1.0

    return stats

@st.cache_resource(show_spinner=False)
def get_embedder():
    # Lazy-init so the UI can load even if Ollama isn't up yet.
    from langchain_community.embeddings import OllamaEmbeddings
    return OllamaEmbeddings(model=EMBED_MODEL)

def ollama_healthcheck():
    base = os.getenv("OLLAMA_BASE_URL") or os.getenv("OLLAMA_HOST") or "http://127.0.0.1:11434"
    try:
        r = requests.get(base.rstrip("/") + "/api/tags", timeout=2.5)
        ok = r.ok
        tags = r.json() if ok else None
        return ok, base, tags
    except Exception:
        return False, base, None

def read_text_from_bytes(data: bytes, filename: str) -> str:
    suffix = Path(filename).suffix.lower()
    if suffix == ".pdf":
        reader = PdfReader(io.BytesIO(data))
        return "".join(page.extract_text() or "" for page in reader.pages)
    elif suffix == ".docx":
        doc = Docx(io.BytesIO(data))
        return "".join(p.text for p in doc.paragraphs)
    elif suffix in {".txt", ".rtf"}:
        txt = data.decode(errors="ignore")
        if suffix == ".rtf":
            # simple strip; for production, consider `striprtf`
            import re
            return re.sub(r"{\rtf1.*?}", "", txt, flags=re.DOTALL)
        return txt
    else:
        raise ValueError(f"Unsupported file type: {suffix}")

def save_bytes_to_store(data: bytes, filename: str) -> Tuple[str, str, str]:
    """
    Save a canonical copy to RESUMES_STORE_DIR.
    Returns (stored_path, sha256_full, short_hash12)
    """
    import hashlib
    h = hashlib.sha256()
    h.update(data)
    sha256_full = h.hexdigest()
    short12 = sha256_full[:12]
    ext = Path(filename).suffix.lower()
    stem = Path(filename).stem
    stored_name = f"{stem}.{short12}{ext}"
    stored_path = os.path.join(RESUMES_STORE_DIR, stored_name)
    if not os.path.exists(stored_path):
        with open(stored_path, "wb") as f:
            f.write(data)
    return stored_path, sha256_full, short12

def load_bm25():
    if os.path.exists(BM25_CORPUS_PATH):
        with open(BM25_CORPUS_PATH, "rb") as f:
            corpus_tokens = pickle.load(f)
    else:
        corpus_tokens = []
    if os.path.exists(BM25_META_PATH):
        with open(BM25_META_PATH, "rb") as f:
            meta_by_id = pickle.load(f)
    else:
        meta_by_id = {}
    if os.path.exists(BM25_DOCIDS_PATH):
        with open(BM25_DOCIDS_PATH, "rb") as f:
            doc_ids = pickle.load(f)
    else:
        doc_ids = []
    return corpus_tokens, meta_by_id, doc_ids

def save_bm25(corpus_tokens, meta_by_id, doc_ids):
    with open(BM25_CORPUS_PATH, "wb") as f:
        pickle.dump(corpus_tokens, f)
    with open(BM25_META_PATH, "wb") as f:
        pickle.dump(meta_by_id, f)
    with open(BM25_DOCIDS_PATH, "wb") as f:
        pickle.dump(doc_ids, f)

def already_exists(coll, sha256: str, local_meta_by_id: dict | None = None) -> bool:
    """Robust duplicate check that works across Chroma versions.
    First checks local metadata cache, then attempts a metadata-filtered get.
    """
    if local_meta_by_id:
        for md in local_meta_by_id.values():
            if md.get("sha256") == sha256:
                return True
    try:
        res = coll.get(where={"sha256": sha256}, include=[], limit=1)
        return bool(res.get("ids"))
    except Exception:
        return False

def normalize_ext(filename: str) -> str:
    return Path(filename).suffix.lower()

SUPPORTED_EXTS = {".pdf", ".docx", ".txt", ".rtf"}

def validate_ext(filename: str) -> bool:
    ext = normalize_ext(filename)
    return ext in SUPPORTED_EXTS

# ---------- LangSmith helpers (tracing + dataset export) ----------

@st.cache_resource(show_spinner=False)
def get_langsmith_client():
    try:
        return Client()
    except Exception as e:
        st.warning(f"LangSmith client not available: {e}")
        return None

@traceable(name="admin.embed_chunks", run_type="embedding")
def _embed_chunks(embedder, chunks: List[str]):
    return embedder.embed_documents(chunks)

@traceable(name="admin.add_one_document", run_type="chain")
def add_one_document(
    coll,
    text: str,
    metadata: Dict,
    base_doc_id: str,
    corpus_tokens: List[List[str]],
    bm25_doc_ids: List[str]
):
    # embedder
    try:
        embedder = get_embedder()
    except Exception:
        st.error(
            "Cannot initialize Ollama embeddings. Make sure Ollama is running and the model is pulled.",
            icon="⚠️",
        )
        raise

    # chunking
    chunks = chunk_text(text, CHUNK_SIZE, CHUNK_OVERLAP)
    if not chunks:
        raise ValueError("No text chunks produced from document")

    # embed in a batch (traced)
    try:
        vecs = _embed_chunks(embedder, chunks)
    except Exception:
        st.error("Embedding request failed. Is the Ollama server reachable and responsive?", icon="⚠️")
        raise

    # per-chunk metadata & ids
    metas = []
    ids = []
    for i, ch in enumerate(chunks):
        cid = f"{base_doc_id}::c{i:04d}"
        m = dict(metadata or {})
        m.update({
            "parent_id": base_doc_id,
            "chunk_index": i,
            "chunk_total": len(chunks),
            "text_len": len(ch),
        })
        m = {k: (v if isinstance(v, (str, int, float, bool)) else str(v)) for k, v in m.items() if v is not None}
        metas.append(m)
        ids.append(cid)
        corpus_tokens.append(tokenize(ch))
        bm25_doc_ids.append(cid)

    coll.add(documents=chunks, metadatas=metas, ids=ids, embeddings=vecs)

    # return detailed chunk stats
    stats = _chunk_stats(chunks, len(text), CHUNK_SIZE, CHUNK_OVERLAP)
    stats.update({
        "base_doc_id": base_doc_id,
    })
    # propagate a few file-level fields for convenience if present
    for k in ("sha256", "short_hash", "source_ext", "source_filename", "file_size_bytes"):
        if k in metadata:
            # promote to top-level names that match earlier UI
            if k == "sha256":
                stats["file_sha256"] = metadata.get(k)
            elif k == "short_hash":
                stats["short_hash"] = metadata.get(k)
            else:
                stats[k] = metadata.get(k)
    return stats

@traceable(name="admin.ingest_file", run_type="chain")
def ingest_file(
    coll,
    file_bytes: bytes,
    filename: str,
    alpha_secs: float,
    local_meta_by_id: Dict[str, Dict],
    corpus_tokens: List[List[str]],
    bm25_doc_ids: List[str],
):
    t0 = time.perf_counter()
    stored_path, sha256_full, short12 = save_bytes_to_store(file_bytes, filename)

    # duplicate check timing
    t_dup0 = time.perf_counter()
    is_dup = already_exists(coll, sha256_full, local_meta_by_id)
    dup_check_ms = (time.perf_counter() - t_dup0) * 1000.0

    result = {
        "source_filename": filename,
        "source_ext": normalize_ext(filename),
        "file_size_bytes": len(file_bytes),
        "file_sha256": sha256_full,
        "short_hash": short12,
        "already_exists_checked": True,
        "duplicate_check_latency_ms": dup_check_ms,
        "is_duplicate_blocked": bool(is_dup),
        "duplicate_reason": "sha256" if is_dup else "none",
        "ingested": False,
        "duration_ms_total": None,
        "error": None,
    }

    if is_dup:
        result["duration_ms_total"] = (time.perf_counter() - t0) * 1000.0
        return result  # early exit; duplicate was blocked

    # extract and clean text
    try:
        text_raw = read_text_from_bytes(file_bytes, filename)
        text = clean_text(text_raw)
        if not text.strip():
            result["duplicate_reason"] = "no_text"
            result["duration_ms_total"] = (time.perf_counter() - t0) * 1000.0
            return result
    except Exception as e:
        result["error"] = f"text_extract_error: {e}"
        result["duration_ms_total"] = (time.perf_counter() - t0) * 1000.0
        return result

    # metadata + id
    md = simple_metadata(text, Path(filename).stem)
    md.update({
        "file_path": stored_path,
        "short_hash": short12,
        "sha256": sha256_full,
        "source_ext": normalize_ext(filename),
        "source_filename": filename,
        "file_size_bytes": len(file_bytes),
    })
    base_id = f"{Path(filename).stem}-{short12}"

    # add to Chroma (also traced), and collect chunk stats
    try:
        stats = add_one_document(coll, text, md, base_id, corpus_tokens, bm25_doc_ids) or {}
        local_meta_by_id[base_id] = md
        result.update(stats)
        result["ingested"] = True
    except Exception as e:
        result["error"] = f"add_error: {e}"

    if alpha_secs and alpha_secs > 0:
        time.sleep(alpha_secs)

    result["duration_ms_total"] = (time.perf_counter() - t0) * 1000.0
    return result

def list_collection(coll) -> pd.DataFrame:
    """Aggregate by parent resume so the table shows one row per resume, not per chunk."""
    page_size = 1000
    ids_all, metas_all = [], []
    offset = 0
    while True:
        batch = coll.get(include=["metadatas"], limit=page_size, offset=offset)
        ids = batch.get("ids", [])
        metas = batch.get("metadatas", [])
        if not ids:
            break
        ids_all.extend(ids)
        metas_all.extend(metas)
        offset += len(ids)

    # aggregate by parent_id
    agg: Dict[str, Dict] = {}
    for _id, m in zip(ids_all, metas_all):
        pid = (m or {}).get("parent_id") or _id.split("::")[0]
        row = agg.get(pid)
        if not row:
            agg[pid] = {
                "document_id": pid,
                "candidate_name": m.get("candidate_name"),
                "email": m.get("email"),
                "phone": m.get("phone"),
                "source_ext": m.get("source_ext"),
                "short_hash": m.get("short_hash"),
                "sha256": m.get("sha256"),
                "file_path": m.get("file_path"),
                "chunks": 1,
            }
        else:
            row["chunks"] = row.get("chunks", 0) + 1

    df = pd.DataFrame(list(agg.values()))
    if not df.empty:
        df = df.sort_values("candidate_name", na_position="last").reset_index(drop=True)
    return df

def export_contacts_dataset_to_langsmith(df: pd.DataFrame, dataset_name: str):
    """Push current inventory to a LangSmith dataset for contact parsing validation."""
    client = get_langsmith_client()
    if client is None:
        st.error("LangSmith client not available. Set LANGSMITH_API_KEY and LANGSMITH_TRACING=true.")
        return
    # create or reuse dataset
    try:
        ds = client.create_dataset(dataset_name, description="Resume parsing/contacts verification examples")
    except Exception:
        # if exists, fetch by name
        ds = None
        try:
            for d in client.list_datasets():
                if getattr(d, "name", None) == dataset_name:
                    ds = d
                    break
        except Exception:
            pass
        if ds is None:
            raise

    # build examples from inventory
    examples = []
    for _, row in df.iterrows():
        fp = row.get("file_path")
        snippet = ""
        try:
            if fp and Path(fp).exists():
                with open(fp, "rb") as fh:
                    data = fh.read()
                snippet = (read_text_from_bytes(data, Path(fp).name) or "")[:2000]
        except Exception:
            snippet = ""

        inputs = {
            "document_id": row.get("document_id"),
            "file_path": fp,
            "text_snippet": snippet,
        }
        reference_outputs = {
            "candidate_name": row.get("candidate_name"),
            "email": row.get("email"),
            "phone": row.get("phone"),
            "source_ext": row.get("source_ext"),
        }
        examples.append({"inputs": inputs, "outputs": reference_outputs})

    # chunk insert
    BATCH = 50
    for i in range(0, len(examples), BATCH):
        client.create_examples(dataset_id=ds.id, examples=examples[i:i+BATCH])

    st.success(f"Pushed {len(examples)} examples to LangSmith dataset: {dataset_name}")

def export_dedup_dataset_to_langsmith(folder: str, dataset_name: str):
    """
    Build a LangSmith dataset for duplicate filtering.
    Each example = one file with its group_id and variant_type.
    Reference outputs:
      - is_strict_duplicate_expected (bool) relative to canonical sha256 per group
      - canonical_file_sha256 (str)
    """
    client = get_langsmith_client()
    if client is None:
        st.error("LangSmith client not available. Set LANGSMITH_API_KEY and LANGSMITH_TRACING=true.")
        return

    root = Path(folder)
    if not root.exists():
        st.error("Folder not found.")
        return

    # scan files grouped by immediate parent folder name
    items = []
    for p in sorted(root.rglob("*")):
        if p.is_file() and p.suffix.lower() in SUPPORTED_EXTS:
            group_id = p.parent.name
            variant_type = "unknown"
            if "_" in group_id:
                variant_type = group_id.split("_", 1)[0]
            with open(p, "rb") as fh:
                data = fh.read()
            sha = hashlib.sha256(data).hexdigest()
            items.append({
                "file_path": str(p.resolve()),
                "group_id": group_id,
                "variant_type": variant_type,
                "sha256": sha,
                "filename": p.name,
            })

    if not items:
        st.warning("No supported files found in the folder.")
        return

    # compute canonical per group (first by filename sort)
    examples = []
    from collections import defaultdict
    groups = defaultdict(list)
    for it in items:
        groups[it["group_id"]].append(it)
    for gid, arr in groups.items():
        arr_sorted = sorted(arr, key=lambda x: x["filename"])
        canonical_sha = arr_sorted[0]["sha256"]
        for it in arr_sorted:
            is_strict_dup_expected = (it["sha256"] == canonical_sha and it["filename"] != arr_sorted[0]["filename"])
            inputs = {
                "file_path": it["file_path"],
                "group_id": gid,
                "variant_type": it["variant_type"],
                "filename": it["filename"],
            }
            outputs = {
                "is_strict_duplicate_expected": bool(is_strict_dup_expected),
                "canonical_file_sha256": canonical_sha,
                "sha256": it["sha256"],
            }
            examples.append({"inputs": inputs, "outputs": outputs})

    # create or reuse dataset
    try:
        ds = client.create_dataset(dataset_name, description="Duplicate filtering test suite for ResumeFinder Admin")
    except Exception:
        ds = None
        try:
            for d in client.list_datasets():
                if getattr(d, "name", None) == dataset_name:
                    ds = d
                    break
        except Exception:
            pass
        if ds is None:
            raise

    BATCH = 50
    for i in range(0, len(examples), BATCH):
        client.create_examples(dataset_id=ds.id, examples=examples[i:i+BATCH])

    st.success(f"Pushed {len(examples)} examples to LangSmith dataset: {dataset_name}")

def export_chunking_dataset_to_langsmith(folder: str, dataset_name: str, size: int, overlap: int):
    """
    Build a LangSmith dataset for chunking quality.
    inputs: file_path, size, overlap
    reference outputs: expected_min_chunks, expected_max_chunks, text_len
    """
    client = get_langsmith_client()
    if client is None:
        st.error("LangSmith client not available. Set LANGSMITH_API_KEY and LANGSMITH_TRACING=true.")
        return

    root = Path(folder)
    if not root.exists():
        st.error("Folder not found.")
        return

    items = []
    for p in sorted(root.rglob("*")):
        if p.is_file() and p.suffix.lower() in {".txt", ".pdf", ".docx", ".rtf"}:
            try:
                with open(p, "rb") as fh:
                    data = fh.read()
                txt = read_text_from_bytes(data, p.name)
                cleaned = clean_text(txt or "")
                tlen = len(cleaned)
                exp = math.ceil(tlen / max(1, int(size)))
                inputs = {
                    "file_path": str(p.resolve()),
                    "size": int(size),
                    "overlap": int(overlap),
                    "filename": p.name,
                }
                outputs = {
                    "expected_min_chunks": max(1, exp - 1),
                    "expected_max_chunks": exp + 1,
                    "text_len": tlen,
                }
                items.append({"inputs": inputs, "outputs": outputs})
            except Exception:
                continue

    if not items:
        st.warning("No supported files found in the folder.")
        return

    # create or reuse dataset
    try:
        ds = client.create_dataset(dataset_name, description="Chunking quality test suite for ResumeFinder Admin")
    except Exception:
        ds = None
        try:
            for d in client.list_datasets():
                if getattr(d, "name", None) == dataset_name:
                    ds = d
                    break
        except Exception:
            pass
        if ds is None:
            raise

    BATCH = 50
    for i in range(0, len(items), BATCH):
        client.create_examples(dataset_id=ds.id, examples=items[i:i+BATCH])

    st.success(f"Pushed {len(items)} examples to LangSmith dataset: {dataset_name}")

# ---------- UI ----------

st.title("JD–Resume Admin")
st.caption("Admins can ingest resumes (bulk or single), avoid duplicates, and view everything stored in the vector DB.")

(client, coll) = get_chroma()
corpus_tokens, meta_by_id, bm25_doc_ids = load_bm25()

# Health check panel for Ollama
ok, base_url, tags = ollama_healthcheck()
health_col1, health_col2 = st.columns([2,3])
with health_col1:
    st.write("**Ollama server**:")
    if ok:
        st.success(f"reachable at {base_url}")
    else:
        st.warning(f"not reachable at {base_url}. Start it with `ollama serve` or ensure the Windows service 'Ollama' is running.")
with health_col2:
    if ok:
        names = [t.get("name", "") for t in (tags or {}).get("models", tags or [])]
        names = names or [m.get("name", "") for m in tags] if isinstance(tags, list) else names
        has_model = any(EMBED_MODEL in (n or "") for n in names)
        if has_model:
            st.info(f"model present: {EMBED_MODEL}")
        else:
            st.warning(f"model NOT found. Run: `ollama pull {EMBED_MODEL}`")

tab_upload, tab_folder, tab_list, tab_langsmith = st.tabs(["Upload files", "Ingest from folder", "Vector DB contents", "LangSmith datasets"])

with tab_upload:
    st.subheader("Upload Word/PDF resumes")
    st.write("Upload one or many .pdf, .docx, .txt, or .rtf files. Duplicates are automatically detected by SHA-256.")

    files = st.file_uploader(
        "Drop files here",
        accept_multiple_files=True,
        type=["pdf", "docx", "txt", "rtf"],
        help="Supported: PDF, DOCX, TXT, RTF"
    )
    colA, colB, _ = st.columns([1,1,2])
    with colA:
        alpha = st.slider("Embedding batch delay (s)", 0.0, 0.5, 0.0, 0.05,
                          help="Optional tiny delay between embeddings if your Ollama box is resource-constrained.")
    with colB:
        do_ingest = st.button("Save to Chroma", type="primary", use_container_width=True)

    if do_ingest and files:
        pbar = st.progress(0.0, text="Starting ingestion…")
        done = 0
        added, skipped = 0, 0
        details = st.empty()
        for f in files:
            try:
                if not validate_ext(f.name):
                    st.warning(f"Unsupported file type: {f.name}. Skipped.")
                    skipped += 1
                    done += 1
                    pbar.progress(done / len(files))
                    continue

                data = f.read()
                result = ingest_file(
                    coll=coll,
                    file_bytes=data,
                    filename=f.name,
                    alpha_secs=alpha,
                    local_meta_by_id=meta_by_id,
                    corpus_tokens=corpus_tokens,
                    bm25_doc_ids=bm25_doc_ids,
                )

                if result.get("is_duplicate_blocked"):
                    st.warning(f"Duplicate detected (SHA-256={result['file_sha256'][:12]}…) → {f.name} skipped.")
                    skipped += 1
                elif result.get("error"):
                    st.error(f"Failed on {f.name}: {result.get('error')}")
                    skipped += 1
                elif result.get("ingested"):
                    added += 1
                    details.info(
                        f"Added: {f.name} → id={result.get('base_doc_id')} "
                        f"(chunks {result.get('chunk_count')}, p95={result.get('chunk_length_p95')})"
                    )
                else:
                    st.warning(f"Skipped {f.name}: {result.get('duplicate_reason','unknown')}")
                    skipped += 1

                done += 1
                pbar.progress(done / len(files))

            except Exception as e:
                skipped += 1
                done += 1
                st.error(f"Failed on {f.name}: {e}")
                pbar.progress(done / len(files))

        save_bm25(corpus_tokens, meta_by_id, bm25_doc_ids)
        pbar.empty()
        st.success(f"Done. Added {added}, skipped {skipped}.")
        st.rerun()

with tab_folder:
    st.subheader("Bulk ingest from a server folder")
    st.write("Point to a folder on this server. All supported files will be parsed, deduped by SHA-256, embedded, and saved.")
    folder = st.text_input("Absolute or relative folder path", value="./resumes_raw")
    run = st.button("Scan & ingest folder", use_container_width=True)
    if run:
        root = Path(folder)
        if not root.exists():
            st.error("Folder not found.")
        else:
            paths: List[Path] = []
            for p in root.rglob("*"):
                if p.is_file() and p.suffix.lower() in SUPPORTED_EXTS:
                    paths.append(p)
            if not paths:
                st.warning("No supported files found.")
            else:
                pbar = st.progress(0.0, text=f"Found {len(paths)} files. Ingesting…")
                added = skipped = 0
                for i, p in enumerate(paths, 1):
                    try:
                        with open(p, "rb") as fh:
                            data = fh.read()
                        result = ingest_file(
                            coll=coll,
                            file_bytes=data,
                            filename=p.name,
                            alpha_secs=0.0,
                            local_meta_by_id=meta_by_id,
                            corpus_tokens=corpus_tokens,
                            bm25_doc_ids=bm25_doc_ids,
                        )
                        if result.get("is_duplicate_blocked"):
                            skipped += 1
                            pbar.progress(i / len(paths), text=f"Skip duplicate: {p.name}")
                        elif result.get("error"):
                            skipped += 1
                            pbar.progress(i / len(paths), text=f"Error on {p.name}: {result.get('error')}")
                        elif result.get("ingested"):
                            added += 1
                            pbar.progress(i / len(paths), text=f"Added: {p.name} (chunks {result.get('chunk_count')})")
                        else:
                            skipped += 1
                            pbar.progress(i / len(paths), text=f"Skipped {p.name}: {result.get('duplicate_reason','unknown')}")

                    except Exception as e:
                        skipped += 1
                        pbar.progress(i / len(paths), text=f"Error on {p.name}: {e}")

                save_bm25(corpus_tokens, meta_by_id, bm25_doc_ids)
                pbar.empty()
                st.success(f"Ingestion finished. Added {added}, skipped {skipped}.")
                st.rerun()

with tab_list:
    st.subheader("Vector database contents")
    st.write("Full inventory of resumes currently stored in Chroma. Grouped by resume (parent), not chunks.")
    df = list_collection(coll)
    left, right = st.columns([1,3])
    with left:
        st.metric("Total resumes", len(df))
    with right:
        st.caption("Tip: Use the column filters/search inside the table to find specific entries quickly. The 'chunks' column shows how many chunks per resume.")
    if df.empty:
        st.info("No resumes found.")
    else:
        show_cols = ["candidate_name", "email", "phone", "source_ext", "document_id", "chunks", "short_hash", "sha256", "file_path"]
        st.dataframe(df[show_cols], use_container_width=True, hide_index=True)
        with st.expander("Export list as CSV"):
            csv = df.to_csv(index=False).encode()
            st.download_button("Download CSV", csv, "chroma_inventory.csv", "text/csv")
    # expose the inventory for dataset export
    st.session_state["__inventory_df"] = df

with tab_langsmith:
    st.subheader("Export inventory as a LangSmith dataset")
    st.write("Creates a dataset of resume entries with text snippets and extracted contacts for human review.")
    default_name = f"rf_parsing_contacts_{int(time.time())}"
    ds_name = st.text_input("Dataset name", value=default_name)
    push = st.button("Create/append dataset in LangSmith", type="primary", use_container_width=True)
    if push:
        inv = st.session_state.get("__inventory_df")
        if inv is None or inv.empty:
            st.warning("Inventory is empty. Ingest resumes first in the other tabs.")
        else:
            export_contacts_dataset_to_langsmith(inv, ds_name)

    st.divider()
    st.subheader("Build duplicate filtering dataset (rf_admin_dedup_suite)")
    st.write("Point to a folder that contains grouped files, e.g.: exact_set_01/, text_identical_01/, near_dup_01/, singleton_01/")
    dedup_folder = st.text_input("Folder path for duplicate dataset", value="./dedup_suite")
    dedup_ds_name = st.text_input("Target dataset name", value="rf_admin_dedup_suite")
    make_dedup = st.button("Create/append duplicate dataset in LangSmith", use_container_width=True)
    if make_dedup:
        export_dedup_dataset_to_langsmith(dedup_folder, dedup_ds_name)

    st.divider()
    st.subheader("Build chunking quality dataset (rf_admin_chunking_suite)")
    st.write("Provide a folder with ~20 texts across lengths/languages. We'll compute expected chunk count bands.")
    chunk_folder = st.text_input("Folder path for chunking dataset", value="./chunking_suite")
    col1, col2 = st.columns(2)
    with col1:
        chunk_ds_name = st.text_input("Target dataset name", value="rf_admin_chunking_suite")
    with col2:
        size = st.number_input("Chunk size", min_value=100, max_value=4000, value=int(CHUNK_SIZE), step=50)
        overlap = st.number_input("Chunk overlap", min_value=0, max_value=2000, value=int(CHUNK_OVERLAP), step=10)
    make_chunk = st.button("Create/append chunking dataset in LangSmith", use_container_width=True)
    if make_chunk:
        export_chunking_dataset_to_langsmith(chunk_folder, chunk_ds_name, int(size), int(overlap))

st.divider()
st.caption("Admin-only interface. Users will not see ingestion or write paths in the end-user app.")
