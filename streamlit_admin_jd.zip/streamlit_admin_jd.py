# streamlit_admin_jds_form.py
# ----------------------------------------------------------------------
# Admin – JD Ingestion via FORM (single-embedding per JD)
# - Does NOT touch your existing admin file
# - Uses the same JD Chroma collection from config_jd
# - Stores one embedding per JD (no chunking)
# - UPDATED: Added fields:
#   1) Job ID
#   2) Requirements and skills (comma separated)
#   3) Qualifications and educations (comma separated)
#   4) Company Name
# ----------------------------------------------------------------------

import os
import io
import re
import pickle
from pathlib import Path
from typing import Dict, List, Tuple

import streamlit as st
import chromadb
import pandas as pd

# Reuse project utilities
from utils_jd import clean_text, tokenize, sanitize_metadata, stable_id_from_bytes

# JD config (same collection as your file-based admin)
from config_jd import (
    CHROMA_DIR, CHROMA_COLLECTION_JDS, JDS_INDEX_DIR,
    BM25_JDS_CORPUS_PATH, BM25_JDS_META_PATH, BM25_JDS_DOCIDS_PATH,
    EMBED_MODEL,
)

# ---- page ----
st.set_page_config(page_title="Admin – JD Form Ingest (Single Embedding)", page_icon="📝", layout="wide")
st.title("Admin – JD Form Ingest (Single Embedding)")
st.caption("Create a JD via form and store it as ONE document with ONE embedding in the same JD collection.")

# ---- helpers ----
def get_chroma():
    client = chromadb.PersistentClient(path=CHROMA_DIR)
    coll = client.get_or_create_collection(
        name=CHROMA_COLLECTION_JDS,
        metadata={"hnsw:space": "cosine"}  # explicit for safety
    )
    os.makedirs(JDS_INDEX_DIR, exist_ok=True)
    return coll

def get_embedder():
    # Lazy import so UI loads even if Ollama isn't up
    from langchain_community.embeddings import OllamaEmbeddings
    return OllamaEmbeddings(model=EMBED_MODEL)

def load_bm25():
    if os.path.exists(BM25_JDS_CORPUS_PATH):
        with open(BM25_JDS_CORPUS_PATH, "rb") as f:
            corpus_tokens = pickle.load(f)
    else:
        corpus_tokens = []
    if os.path.exists(BM25_JDS_META_PATH):
        with open(BM25_JDS_META_PATH, "rb") as f:
            meta_by_id = pickle.load(f)
    else:
        meta_by_id = {}
    if os.path.exists(BM25_JDS_DOCIDS_PATH):
        with open(BM25_JDS_DOCIDS_PATH, "rb") as f:
            bm25_doc_ids = pickle.load(f)
    else:
        bm25_doc_ids = []
    return corpus_tokens, meta_by_id, bm25_doc_ids

def save_bm25(corpus_tokens, meta_by_id, bm25_doc_ids):
    with open(BM25_JDS_CORPUS_PATH, "wb") as f:
        pickle.dump(corpus_tokens, f)
    with open(BM25_JDS_META_PATH, "wb") as f:
        pickle.dump(meta_by_id, f)
    with open(BM25_JDS_DOCIDS_PATH, "wb") as f:
        pickle.dump(bm25_doc_ids, f)

def slugify(s: str) -> str:
    s = re.sub(r"[^a-zA-Z0-9._-]+", "_", s or "").strip("_")
    return s or "jd"

def _split_csv(s: str) -> List[str]:
    return [x.strip() for x in (s or "").split(",") if x.strip()]

def compose_text_from_form(
    employer_id: str,
    job_id_external: str,
    job_title: str,
    company_name: str,
    description: str,
    location: str,
    job_type: str,
    min_salary: float,
    max_salary: float,
    required_skills: List[str],
    requirements_skills: List[str],
    qualifications_educations: List[str],
    posted_date: str,
    anonymous_posting: bool,
    is_active: bool,
    created_at: str,
    updated_at: str,
) -> str:
    txt = f"""
EmployerId: {employer_id}
Job ID: {job_id_external}
Company Name: {company_name}
Job Title: {job_title}
Description: {description}
Location: {location}
Job Type: {job_type}
Min Salary: {min_salary}
Max Salary: {max_salary}
Required Skills: {", ".join(required_skills)}
Requirements & Skills: {", ".join(requirements_skills)}
Qualifications & Educations: {", ".join(qualifications_educations)}
Posted Date: {posted_date}
Anonymous Posting: {anonymous_posting}
Is Active: {is_active}
Created At: {created_at}
Updated At: {updated_at}
""".strip()
    return clean_text(txt)

# ---- UI: form + inventory ----
tab_form, tab_inv = st.tabs(["➕ New JD (Form)", "📦 Inventory"])

with tab_form:
    st.subheader("Create a JD via Form (single embedding)")

    with st.form("jd_form", clear_on_submit=False):
        employer_id = st.text_input("EmployerId", value="1")
        # NEW fields
        job_id_external = st.text_input("Job ID", value="")
        company_name = st.text_input("Company Name", value="")
        # Existing fields
        job_title = st.text_input("Job title", value="Java Full Stack Developer")
        description = st.text_area("Description", value="Should have knowledge on designing and developing both front-end user …", height=200)
        location = st.text_input("Location", value="Hyderabad")
        job_type = st.selectbox("JobType", options=["FULL_TIME", "PART_TIME", "CONTRACT", "INTERNSHIP", "TEMPORARY"], index=0)
        min_salary = st.number_input("MinSalary", value=30000, step=1000)
        max_salary = st.number_input("MaxSalary", value=50000, step=1000)
        # Existing skills + NEW requirements/qualifications
        required_skills_text = st.text_input("RequiredSkills (comma-separated)", value="Java, Springboot, Hibernate, Html")
        requirements_and_skills_text = st.text_input("Requirements and skills (comma separated)", value="")
        qualifications_and_educations_text = st.text_input("Qualifications and educations (comma separated)", value="")
        posted_date = st.text_input("PostedDate", value="2025-08-28T13:03:02.686+00:00")
        anonymous_posting = st.checkbox("AnonymousPosting", value=False)
        is_active = st.checkbox("IsActive", value=True)
        created_at = st.text_input("CreatedAt", value="2025-08-28T13:03:02.748+00:00")
        updated_at = st.text_input("UpdatedAt", value="2025-08-28T13:03:02.748+00:00")
        submit = st.form_submit_button("Ingest JD")

    if submit:
        try:
            # Parse CSV-like fields
            required_skills_list = _split_csv(required_skills_text)
            requirements_skills_list = _split_csv(requirements_and_skills_text)
            qualifications_educations_list = _split_csv(qualifications_and_educations_text)

            text = compose_text_from_form(
                employer_id=employer_id,
                job_id_external=job_id_external,
                job_title=job_title,
                company_name=company_name,
                description=description,
                location=location,
                job_type=job_type,
                min_salary=min_salary,
                max_salary=max_salary,
                required_skills=required_skills_list,
                requirements_skills=requirements_skills_list,
                qualifications_educations=qualifications_educations_list,
                posted_date=posted_date,
                anonymous_posting=anonymous_posting,
                is_active=is_active,
                created_at=created_at,
                updated_at=updated_at,
            )

            if not text:
                st.warning("Form is empty after cleaning.")
                st.stop()

            coll = get_chroma()
            corpus_tokens, meta_by_id, bm25_doc_ids = load_bm25()

            # Use the composed text for dedupe + stable id
            sha256_full, short12 = stable_id_from_bytes(text.encode("utf-8"))
            # dedupe on content hash
            if any(md.get("sha256") == sha256_full for md in meta_by_id.values()):
                st.info("This JD content already exists (duplicate by content hash).")
                st.stop()

            base_id = f"{slugify(job_title)}.{short12}"
            chunk_id = f"{base_id}::chunk_0"  # single chunk id

            # Combine skills for a compact "required_skills" field while retaining the new fields as well
            combined_skills = list(dict.fromkeys(required_skills_list + requirements_skills_list))  # de-dup preserve order

            # Metadata (kept simple and sanitized)
            md = sanitize_metadata({
                "job_id": base_id,                        # internal parent id used by matchers
                "job_id_external": job_id_external,       # NEW: external Job ID from the form
                "title": job_title,
                "company": company_name,                   # NEW: company name
                "employer_id": str(employer_id),
                "location": location,
                "url": "",
                "source_ext": "form",
                "sha256": sha256_full,
                "short_hash": short12,
                # Optional mirrors of form fields:
                "job_type": job_type,
                "min_salary": float(min_salary),
                "max_salary": float(max_salary),
                "required_skills": ", ".join(combined_skills),                 # combined compact
                "requirements_skills": ", ".join(requirements_skills_list),    # NEW
                "qualifications_educations": ", ".join(qualifications_educations_list),  # NEW
                "posted_date": posted_date,
                "anonymous_posting": bool(anonymous_posting),
                "is_active": bool(is_active),
                "created_at": created_at,
                "updated_at": updated_at,
                "embed_model": EMBED_MODEL,
            })

            # Embed as ONE document (no chunking)
            embedder = get_embedder()
            vec = embedder.embed_documents([text])  # returns [vector]

            # Write to Chroma (single doc)
            coll.add(
                documents=[text],
                metadatas=[md],
                ids=[chunk_id],
                embeddings=vec
            )

            # Keep BM25 artifacts consistent (optional but harmless)
            corpus_tokens.append(tokenize(text))
            bm25_doc_ids.append(chunk_id)
            meta_by_id[base_id] = md
            save_bm25(corpus_tokens, meta_by_id, bm25_doc_ids)

            st.success(f"Ingested JD as single embedding: {base_id}")
            st.caption(f"External Job ID: {job_id_external or '—'}  •  Company: {company_name or '—'}")
        except Exception as e:
            st.error(f"Failed to ingest JD from form: {e}", icon="⚠️")

with tab_inv:
    st.subheader("JD Inventory (Form + Files)")
    coll = get_chroma()

    # collect parent-level
    ids_all, metas_all = [], []
    offset, page = 0, 500
    while True:
        batch = coll.get(include=["metadatas"], limit=page, offset=offset)
        _ids = batch.get("ids", [])
        _metas = batch.get("metadatas", [])
        if not _ids:
            break
        ids_all.extend(_ids)
        metas_all.extend(_metas)
        offset += len(_ids)

    agg = {}
    for _id, md in zip(ids_all, metas_all):
        if not md:
            continue
        pid = md.get("job_id") or md.get("parent_id") or _id.split("::")[0]
        row = agg.get(pid) or {
            "job_id": pid,
            "job_id_external": md.get("job_id_external"),
            "title": md.get("title"),
            "company": md.get("company"),
            "location": md.get("location"),
            "url": md.get("url"),
            "source_ext": md.get("source_ext"),
            "short_hash": md.get("short_hash"),
            "sha256": md.get("sha256"),
            "chunks": 0,
        }
        row["chunks"] = row.get("chunks", 0) + 1
        agg[pid] = row

    df = pd.DataFrame(list(agg.values()))
    if df.empty:
        st.info("No JDs indexed yet.")
    else:
        show = ["title", "company", "location", "job_id", "job_id_external", "chunks", "source_ext", "short_hash", "sha256"]
        for col in show:
            if col not in df.columns:
                df[col] = None
        st.dataframe(df[show], use_container_width=True, hide_index=True)
