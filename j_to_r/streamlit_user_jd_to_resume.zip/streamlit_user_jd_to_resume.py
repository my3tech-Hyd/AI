# streamlit_user_jd_to_resume.py
# ----------------------------------------------------------------------
# JD → Resume semantic matcher (cosine only, no BM25)
# - Upload a JD (pdf/docx/txt/rtf/doc)
# - We embed the JD (pooled across chunks) using Ollama embeddings
# - Query a separate Chroma collection that contains RESUME chunks
# - Convert distances → similarities, normalize, aggregate per resume
# - Rank resumes and show top matches with evidence preview
# ----------------------------------------------------------------------

from __future__ import annotations

import io
import os
from pathlib import Path
from typing import Dict, List

import requests
import streamlit as st
import pandas as pd
import chromadb
from pypdf import PdfReader
from docx import Document as Docx

# Reuse cleaning from the shared utils
from utils_r import clean_text

# Config for the RESUMES corpus (isolated DB + env-driven knobs)
from config_jds_resumes import (
    CHROMA_DIR_RESUMES,
    CHROMA_COLLECTION_RESUMES,
    OLLAMA_HOST,
    EMBED_MODEL,
    # Retrieval / pooling knobs (loaded from .env by config_jds_resumes)
    R2J_QUERY_CHUNK_SIZE,
    R2J_QUERY_CHUNK_OVERLAP,
    R2J_QUERY_MAX_CHUNKS,
    R2J_TOP_K_VECTOR,
    R2J_TOP_K_FINAL,
)

# Additional local tunable (okay if missing in .env)
MAX_QUERY_CHARS = int(os.getenv("R2J_MAX_QUERY_CHARS", "1200"))
OLLAMA_TIMEOUT = float(os.getenv("OLLAMA_TIMEOUT", "45"))

# ----------------------------------------------------------------------
# Streamlit UI config
# ----------------------------------------------------------------------
st.set_page_config(
    page_title="JD → Resume Search (Semantic Only)",
    page_icon="🔁",
    layout="wide",
)
st.title("JD → Resume Search (Semantic Only)")
st.caption(
    "Uploads a JD and finds the most relevant **resumes** using cosine similarity over a separate Chroma collection."
)

# ----------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------
def read_text_from_bytes(data: bytes, filename: str) -> str:
    """
    Extract text from common formats and clean it.
    Supports: .pdf, .docx, .txt, .rtf, .md, .doc (best-effort decode)
    """
    ext = Path(filename).suffix.lower()
    try:
        if ext == ".pdf":
            with io.BytesIO(data) as f:
                reader = PdfReader(f, strict=False)
                text = " ".join((page.extract_text() or "") for page in reader.pages)
        elif ext == ".docx":
            with io.BytesIO(data) as f:
                doc = Docx(f)
                text = "\n".join(p.text for p in doc.paragraphs)
        elif ext in {".txt", ".rtf", ".md"}:
            text = data.decode(errors="ignore")
        else:
            # .doc or unknown → best-effort decode
            text = data.decode(errors="ignore")
    except Exception:
        # Fallback to raw decode if any parser chokes
        text = data.decode(errors="ignore")
    return clean_text(text)


def _chunk_query_text(text: str, size: int, overlap: int, max_chunks: int) -> List[str]:
    """
    Split the (possibly long) JD text into smaller chunks so we can embed
    and pooled-average them for a more stable query vector.
    """
    t = text[:MAX_QUERY_CHARS] if MAX_QUERY_CHARS > 0 else text
    n = len(t)
    if n == 0:
        return []
    size = max(1, int(size))
    overlap = max(0, int(overlap))
    if overlap >= size:
        overlap = size // 4  # safety
    chunks: List[str] = []
    start = 0
    while start < n and len(chunks) < max_chunks:
        end = min(n, start + size)
        chunks.append(t[start:end])
        if end == n:
            break
        start = end - overlap
    return chunks


def _embed_query_ollama(chunk: str) -> List[float]:
    """
    Call Ollama's embeddings API directly.
    Requires: ollama serve  &  ollama pull <EMBED_MODEL>
    """
    resp = requests.post(
        f"{OLLAMA_HOST}/api/embeddings",
        json={"model": EMBED_MODEL, "prompt": chunk},
        timeout=OLLAMA_TIMEOUT,
    )
    resp.raise_for_status()
    data = resp.json()
    # Ollama returns either {'embedding': [...]} or {'data': [{'embedding': [...]}]}
    vec = data.get("embedding") or (data.get("data") or [{}])[0].get("embedding")
    if not isinstance(vec, list) or not all(isinstance(x, (int, float)) for x in vec):
        raise ValueError("Invalid embedding vector from Ollama")
    return [float(x) for x in vec]


def _embed_query_pooled(text: str) -> List[float]:
    """
    Pool embeddings across several overlapping chunks of the JD text.
    Length-weighted mean pooling.
    """
    chunks = _chunk_query_text(text, R2J_QUERY_CHUNK_SIZE, R2J_QUERY_CHUNK_OVERLAP, R2J_QUERY_MAX_CHUNKS)
    if not chunks:
        return []
    vecs = [_embed_query_ollama(ch) for ch in chunks]
    dims = len(vecs[0])
    pooled = [0.0] * dims
    weights = [len(ch) for ch in chunks]
    denom = float(sum(weights) or 1.0)
    for v, w in zip(vecs, weights):
        if len(v) != dims:
            # Skip malformed vectors (defensive)
            continue
        wf = float(w)
        for i in range(dims):
            pooled[i] += wf * float(v[i])
    for i in range(dims):
        pooled[i] /= denom
    return pooled


def _normalize(xs: List[float]) -> List[float]:
    """Min–max normalize to [0,1] (stable even with equal values)."""
    if not xs:
        return xs
    lo, hi = min(xs), max(xs)
    if hi - lo < 1e-12:
        return [0.0 for _ in xs]
    scale = hi - lo
    return [(x - lo) / scale for x in xs]


def _distances_to_similarities(dists: List[float]) -> List[float]:
    """
    Convert Chroma distances to a similarity proxy.
    For cosine distance `d_cos`, a simple proxy is `sim = 1 - d`.
    """
    return [1.0 - float(d) for d in dists]


def _get_resume_collection():
    client = chromadb.PersistentClient(path=CHROMA_DIR_RESUMES)
    return client.get_or_create_collection(name=CHROMA_COLLECTION_RESUMES)


def _semantic_search(jd_text: str, coll) -> List[Dict]:
    """
    JD text → (pooled) embedding → Chroma query over RESUME chunks →
    normalize similarities → aggregate to parent resume → rank.
    """
    qvec = _embed_query_pooled(jd_text)
    if not qvec:
        return []

    res = coll.query(
        query_embeddings=[qvec],
        n_results=R2J_TOP_K_VECTOR,
        include=["documents", "distances", "metadatas"],
    )
    ids = res.get("ids", [[]])[0]
    dists = res.get("distances", [[]])[0]
    metas = res.get("metadatas", [[]])[0]
    docs = res.get("documents", [[]])[0]

    sims = _distances_to_similarities([float(d) for d in dists])
    sims_norm = _normalize(sims)

    # Collect chunk-level rows
    rows: List[Dict] = []
    for _id, md, doc, s in zip(ids, metas, docs, sims_norm):
        rows.append(
            {
                "chunk_id": _id,
                "resume_id": (md or {}).get("resume_id") or (md or {}).get("parent_id") or (_id.split("::")[0] if _id else None),
                "candidate_name": (md or {}).get("candidate_name"),
                "email": (md or {}).get("email"),
                "phone": (md or {}).get("phone"),
                "sim": float(s),
                "preview": (doc or "")[:320].replace("\n", " "),
            }
        )

    # Aggregate to parent resume: keep the best chunk as the representative evidence
    by_parent: Dict[str, Dict] = {}
    for r in rows:
        pid = r.get("resume_id")
        cur = by_parent.get(pid)
        if (not cur) or (r["sim"] > cur["sim"]):
            by_parent[pid] = r

    ranked = sorted(by_parent.values(), key=lambda x: x["sim"], reverse=True)[: R2J_TOP_K_FINAL]
    if not ranked:
        return []

    # Relative Match% scaling within the top-k (for easier reading)
    hi = max(x["sim"] for x in ranked) or 1.0
    lo = min(x["sim"] for x in ranked)
    span = hi - lo if hi > lo else 1.0
    for x in ranked:
        x["match_pct"] = round(100.0 * ((x["sim"] - lo) / span), 1)

    return ranked


# ----------------------------------------------------------------------
# UI
# ----------------------------------------------------------------------
left, right = st.columns([1, 1])

with left:
    # ---------- New Job Post Form (replaces file upload) ----------
    with st.form("new_job_post_form", clear_on_submit=False):
        employer_id = st.text_input("EmployerId", value="1")
        job_title = st.text_input("Job title", value="Java Full Stack Developer")
        description = st.text_area("Description", value="Should have knowledge on designing and developing both front-end user …", height=200)
        location = st.text_input("Location", value="Hyderabad")
        job_type = st.selectbox("JobType", options=["FULL_TIME", "PART_TIME", "CONTRACT", "INTERNSHIP", "TEMPORARY"], index=0)
        min_salary = st.number_input("MinSalary", value=30000, step=1000)
        max_salary = st.number_input("MaxSalary", value=50000, step=1000)
        required_skills_text = st.text_input("RequiredSkills (comma-separated)", value="Java, Springboot, Hibernate, Html")
        posted_date = st.text_input("PostedDate", value="2025-08-28T13:03:02.686+00:00")
        anonymous_posting = st.checkbox("AnonymousPosting", value=False)
        is_active = st.checkbox("IsActive", value=True)
        created_at = st.text_input("CreatedAt", value="2025-08-28T13:03:02.748+00:00")
        updated_at = st.text_input("UpdatedAt", value="2025-08-28T13:03:02.748+00:00")
        run_btn = st.form_submit_button("Find matching resumes")

with right:
    st.subheader("Settings & Info")
    st.write(f"Chroma dir: `{CHROMA_DIR_RESUMES}`")
    st.write(f"Collection: `{CHROMA_COLLECTION_RESUMES}`")
    st.write(f"Embeddings via Ollama: `{EMBED_MODEL}` at `{OLLAMA_HOST}`")
    st.markdown(
        f"""
- Query pooling: `{R2J_QUERY_CHUNK_SIZE}` size, `{R2J_QUERY_CHUNK_OVERLAP}` overlap, `{R2J_QUERY_MAX_CHUNKS}` chunks  
- Retrieval: top `{R2J_TOP_K_VECTOR}` chunks → top `{R2J_TOP_K_FINAL}` resumes  
- Tip: ensure you've **ingested resumes** using your *Resume Admin* tool (separate collection).
"""
    )

# ----------------------------------------------------------------------
# Run search
# ----------------------------------------------------------------------
if run_btn:
    try:
        # Compose a JD text from the form fields (then clean, chunk, embed)
        skills_list = [s.strip() for s in required_skills_text.split(",") if s.strip()]
        composed_text = f"""
EmployerId: {employer_id}
Job Title: {job_title}
Description: {description}
Location: {location}
Job Type: {job_type}
Min Salary: {min_salary}
Max Salary: {max_salary}
Required Skills: {", ".join(skills_list)}
Posted Date: {posted_date}
Anonymous Posting: {anonymous_posting}
Is Active: {is_active}
Created At: {created_at}
Updated At: {updated_at}
""".strip()
        text = clean_text(composed_text)

        if not text.strip():
            st.warning("This form seems empty after parsing/cleaning.")
        else:
            coll = _get_resume_collection()
            results = _semantic_search(text, coll)

            if not results:
                st.info("No results. Make sure you've ingested resumes in the resume collection.")
            else:
                df = pd.DataFrame(results)
                show_cols = [
                    "match_pct",
                    "candidate_name",
                    "email",
                    "phone",
                    "resume_id",
                    "sim",
                    "preview",
                ]
                # Ensure all columns exist for display
                for c in show_cols:
                    if c not in df.columns:
                        df[c] = None
                st.dataframe(df[show_cols], use_container_width=True, hide_index=True)
                with st.expander("Download results"):
                    csv = df[show_cols].to_csv(index=False).encode()
                    st.download_button(
                        "Download CSV",
                        data=csv,
                        file_name="jd_to_resume_results.csv",
                        mime="text/csv",
                    )
                st.caption(
                    "Match% is relative within this result set. "
                    "'sim' is normalized cosine similarity (best-chunk evidence per resume)."
                )
    except requests.RequestException as e:
        st.error(
            f"Embedding call to Ollama failed. "
            f"Is Ollama running and the model `{EMBED_MODEL}` pulled? Details: {e}",
            icon="⚠️",
        )
    except Exception as e:
        st.error(f"Search failed: {e}")
